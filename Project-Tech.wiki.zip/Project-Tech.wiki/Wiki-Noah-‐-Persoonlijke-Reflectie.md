## Introductie & Teamrol ##

Binnen ons team zie ik mezelf als een proactieve en kritische ontwerper/ontwikkelaar. Mijn focus lag dit project op de Crew-Profile pagina. 
Ik heb tijdens deze samenwerking veel geprobeerd de mening van anderen te peilen. Voor mij is het essentieel dat iedereen een gelijkwaardige stem heeft in het eindresultaat. Ik vraag daarom actief om feedback op mijn werk en ben zelf ook kritisch naar mijn teamgenoten. Ik geloof dat deze kritische houding de kwaliteit van ons product verbetert en ons dwingt om elke ontwerpkeuze goed te onderbouwen.

Hoewel ik mezelf als zeer aanspreekbaar zie, ben ik me ervan bewust dat ik vaak een volle agenda heb en druk ben. Soms twijfel ik of mijn toewijding aan het project wel goed overkomt op de groep, of dat zij het gevoel hebben dat ik er "maling" aan heb. Uit de feedbacksessies bleek gelukkig dat mijn luchtige houding en humor juist gewaardeerd worden als een fijne afwisseling, zolang ik me serieus bezig houdt met het project. 


## Ontvangen Feedback op Teamrol ##

In de gezamenlijke sessies kwam de volgende feedback naar voren:

Communicatie & Planning: Ik moet beter communiceren wanneer mijn strakke planning niet uitkomt (bijvoorbeeld door laat doorwerken en wekkers die niet goed staan).

Houding: Mijn poging om mensen bij het proces te betrekken kan soms "aanvallend" overkomen. De tip was om eerder vragen te stellen in plaats van direct een mening te geven.

Betrouwbaarheid: Het team gaf aan dat ik mijn taken netjes op tijd afkrijg en afspraken nakom.

Sfeer: Mijn luchtigheid wordt gezien als een positieve bijdrage aan de groepsdynamiek.


## Conclusie ##
Ik heb dit project geleerd dat mijn kritische blik een kracht is voor het product, maar dat de manier waarop ik deze deel (minder aanvallend, meer vragend) cruciaal is voor de samenwerking. Mijn technische vaardigheden in zijn gegroeid, maar in toekomstige projecten zie ik nog veel verbetering door te beginnen met het creeren van de backend en daar later de partials aan te koppelen met genoeg commentaar in de code. Dit zorgt ervoor dat ik niet mijn frontend hoeft te breken maar alles kan maken met een werkende backend en dit zorgt er voor dat andere en ik zelf mijn vele documenten volledig begrijpen en kunnen hergebruiken. Mijn grootste winst zit in het durven aanpassen van een concept op basis van gestructureerde evaluatie, feedback en het vertalen van gebruikersbehoeften naar functionele code. Ik begin met de korte stage op 15 april en in het bedrijf waar ik ga werken zal ik veel feedback krijgen van verschillende afdelingen op mijn designs, door dit project voel ik me daar wat meer voorbereid op. 

##  Gebruikerstest ##

Datum: 27 maart 2026

Testpersoon: Megan (Vriendin van Noah) Media and Culture student

Methode: Think-Aloud (Hardop denken tijdens navigatie)

### Doel van de test
Controleren of een potentiële gebruiker (iemand die werk zoekt in de filmwereld) intuïtief haar weg kan vinden op de projectpagina en of de vacature-sectie duidelijk genoeg is om op te solliciteren.

### Scenario & Taken
Ik heb de testpersoon de volgende opdrachten gegeven zonder uitleg vooraf:

"Bekijk het project en vertel me wat voor sfeer het uitstraalt."

"Zoek uit welke functies er nog openstaan voor dit project."

"Probeer te solliciteren op de functie van Sound Designer."

"Stel je voor dat je de eigenaar bent, voeg een nieuwe vacature toe."

### Observaties & Feedback

****De Layout**** 

Observatie: Bij taak 2 begon de testpersoon te scrollen in de carousel. Ze moest drie keer swipen om alle 5 de vacatures te zien.

Megan: "__Het ziet er leuk uit, maar ik vergeet een beetje wat er aan het begin stond. Ik wil eigenlijk gewoon in één keer zien wat voor vacatures er zijn zonder dat ik moet scrollen door kaartjes.__"

Inzicht: De carousel zorgt voor te weinig overzicht, het is niet goed te zien waar de werkgever naar opzoek is. 

****Visuele Hiërarchie****

Observatie: De sollicitatieknop viel in de eerste versie weg tegen de achtergrond. De testpersoon zocht even naar waar ze precies moest klikken.

Megan: "__De knop mag wel iets meer kleur en wat groter. Nu lijkt het een beetje op de rest van de tekst.__"

****Edit-Mode****

Observatie: Het toevoegen van een beroep via de "Plus-kaart" werd direct begrepen, maar ze wist niet zeker of het opgeslagen was omdat er geen bevestiging kwam.

### Verwerking van de Feedback
Op basis van deze test heb ik de volgende wijzigingen direct doorgevoerd in de code:

Grid-layout: Ik heb de applicationCarousel.js omgebouwd naar een grid-systeem met 2 kolommen. Hierdoor zijn alle vacatures direct zichtbaar zonder te scrollen.

Contrast-verbetering: Ik heb de btn-apply een fellere kleur gegeven (rekening houdend met WCAG-contrast) zodat de Call-to-Action (CTA) duidelijker is.

Feedback-loops: Ik heb JavaScript alerts en visuele statussen ("Verzoek verstuurd") toegevoegd, zodat de gebruiker weet dat de actie is geslaagd.

Marges: De kaarten stonden te krap op elkaar; ik heb de gap in de CSS-grid verhoogd.

### Reflectie op de test

Door deze test met een echte "user" (iemand uit de filmrichting) te doen, kwam ik erachter dat mijn eigen voorkeur voor een carousel (omdat het 'mooi' was) niet matchte met de functionele behoefte van de gebruiker. Dit heeft de bruikbaarheid van mijn crew-profile pagina verbeterd.