# Feedback

### Feedback aan team ??:
* Logo verspringt redelijk vaak
* Gaat de chat ook echt werken en echt encrypted zijn?
* 

## Feedback van team ??
-- Noah:
* onder bij open sollicitaties, valt niet genoeg op op de site. zou meer informatie over de sollicitatie zelf moeten kunnen zien.
* zou veel planning verschil tussen functies kunnen zitten, kan beter uitgelicht worden.
* de kaarten in de carousel zijn te krap op elkaar, niet genoeg marges.

-- Sarah:
* optie zou zijn: dat je per type profiel verschillende filters krijgt.
* filter - meer onderscheid tussen filters. als je naar iets specifieks zoekt wil je die informatie sneller kunnen zien zoals bijvoorbeeld subgenres.
* carousel om te kijken naar banen miss niet gebruiksvriendelijk. kan kijken naar 2 naast elkaar en in kolommen.
* carousel kan bij teveel opties niet makkelijk te gebruiken zijn omdat je te veel zou moeten scrollen.
* kijken naar het teruggaan van pagina, kijken hoe het werkt met terugscrollen.

* verschillende opties maken en feedback naar vragen.

-- Anna-Pari:
* mooie naam
* filter zijn verschillende kleuren, ff kiezen welke - geel?
* eigen film toevoegen?
* bij de project cards is de foto misschien te groot? kan meer balans tussen zijn.
* kruisje valt niet heel erg op.
* er moet meer informatie over het project zijn waar je aan gewerkt hebt?
* kijken naar wat voor informatie dat dan zou zijn.
* 

-- Wietse
* Feedback login pagina, partials
* Sterretjes van verplicht
* Hou je bij wanneer je je leeftijd invoert, dus als je ouder wordt het aanpast
* Dus de vraag: kiest je als functie uit opties of vul je die zelf in in een open veld
* Misschien bij registreer, niet alleen underline maar nog iets met de opacity (geel)

Vraag aan team:
-- Miss een idee om een aparte header te maken met "profiel" ipv login wanneer je bent ingelogd?
- op basis van of je ingelogd ben de juiste header laten zien.