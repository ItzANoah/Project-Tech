In week 9 (plus het weekend) zaten we echt in de eindsprint. Deze week was iedereen vooral individueel bezig met de features afkrijgen, we liepen redelijk op schema, maar toch moest er nog veel gebeuren. Vooral het bijhouden van de DR en de Wiki's moest nog veel aan gebeuren.

De vormgeving van de website was inmiddels af, het was voornamelijk het finetunen in de javascript en het mergen van branches wat het meeste tijd kostte deze week. In het mergen liepen we wel tegen conflicts aan, maar deze vielen mee gelukkig.

Het uitwerken van de DR en Wiki hadden we verdeeld per teamlid, maar we leerde later dat ieder de competenties per persoon moest schrijven.
Dit gaf iets meer werk maar lukte gelukkig allemaal.

Ook Lukte het eindelijk om de website te hosten via Render. hiermee is deze makkelijker te bezoeken en hoeft niet iedereen de repository te clonen om de website via hun eigen laptop te bekijken.
Nadat dit was gelukt hebben we de Planning geupdate, de Wiki en DR afgerond en waren we klaar om in te leveren.