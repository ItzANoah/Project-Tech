<img width="1578" height="962" alt="image" src="https://github.com/user-attachments/assets/622b0d67-84ae-4429-92af-2afc59a9fbda" />
<img width="1644" height="998" alt="image" src="https://github.com/user-attachments/assets/840ae058-f85c-482b-b65d-4ff0d09e83bc" />
<img width="1678" height="1008" alt="image" src="https://github.com/user-attachments/assets/344c63ab-f1b0-4974-bb2f-f97c31014747" />
<img width="1354" height="1062" alt="image" src="https://github.com/user-attachments/assets/1846d5ac-d52b-4df3-8825-9fc5ba6b146e" />




In ons groepje probeer ik vaak naar de mening van andere te vragen zodat iedereen hun mening evenveel meedraagt aan ons eindresultaat. Ook vraag ik om veel feedback en geef ik dit vaak ook, ik denk dat kritisch zijn de kwaliteit erg verbeterd en ervoor zorgt dat je alles wat je doet ook goed kan onderbouwen. Ik ben erg aanspreekbaar maar ben wel vaak druk, ik hoop dat mij groepje ziet dat ze mij altijd kunnen benaderen om te helpen of iets te kunnen maken. Soms betwijfel ik of dit goed overkomt en of zijn misschien niet denken dat ik maling heb aan het project. 

## Feedbackvragen ## 

### Wat is één ding dat ik volgens jullie zou kunnen verbeteren in mijn manier van samenwerken? 
Beter opletten met wekker goed zetten in combinatie met laat in de avond werken, zodra dit niet uitkomt beter communiceren.
Als ik probeer mensen erbij te betrekken komt het aanvallend over, stel eerder vragen betrek ze eerder in het process. 

### Vinden jullie dat ik mijn taken op tijd afkrijg en de afspraken nakom?
ja, taken worden netjes optijd afgemaakt. 

### Communiceer ik duidelijk genoeg over waar ik mee bezig ben?
ja, duidelijk aangegeven wat je aan het doen bent.

### Hebben jullie last van mijn gedrag, hoe ik vaak luchtig ben en andere probeer te laten lachen?
Gezellig en goeie sfeer, het moet duidelijk zijn dat het luchtig is en goed bedoeld is maar je kan ook serieus zijn dus het is een fijne afwisseling.


## Oriënteren en begrijpen ## 

We hebben afgelopen week met z’n alle vooral gewerkt aan het afkrijgen van onze wireframes en het opzetten van de volledig werkende repository. Hierbij hebben we de rollen onderverdeeld wie welke schermen maakt. Ik heb gewerkt aan de profiel pagina van de crew. We missen nu nog een scherm waar je de sollicitanten kan goedkeuren. 

## Verbeelden en conceptualiseren ##

De belangen van onze gebruikers die wij hebben verwerkt is de mogelijkheid om met je creaties en portfolio te kunnen kijken en aanmelden voor werkzaamheden in jouw vakgebied. We hebben het design aangepast om een film uitstraling te geven. Ik heb zelf gesproken met iemand die ik ken en zelf mogelijk opzoek is naar een crew aan de hand van haar cv. Ik heb haar gevraagd wat ze graag zou willen kunnen delen en wat ze zou willen hebben/weten qua informatie van een mogelijke crew. 

## Prototypen en uitwerken  ##  

Wij hebben het onderwerp van onze website gekozen als groep. Dit hebben we gedaan aan de hand van meerdere woordwebben waarbij we in het begin erg breed begonnen en steeds meer ideeën samenvoegden. Tijdens dit process stelden we elkaar steeds kritische vragen om zo tot de kern te komen van goede ideeën. 