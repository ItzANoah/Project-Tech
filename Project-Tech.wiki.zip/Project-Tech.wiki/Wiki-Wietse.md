> Individuele wiki (markdown bestand)
> Elk teamlid heeft een eigen pagina in de wiki van de Github repository van het team. Je reflecteert hierin op jouw rol binnen het team en de persoonlijke ontwikkeling die je doormaakt. Er worden meerdere malen feedbacksessies georganiseerd waarin je als team je voortgang presenteert en feedback over jouw rol in het team ophaalt. De feedback die je van medestudenten en docenten ontvangt, verwerk je ook in deze individuele wiki. Je gebruikt deze pagina ook om naast feedbackvragen ook concrete hulpvragen te formuleren die je aan je team of docent wil stellen. Waar loop je in vast en heb je hulp bij nodig?

> Voor de competentie samen ontwerpen schrijf je een individuele reflectie waarin je een toelichting geeft op jouw teamrol en de wijze waarop je omgaat met het vragen van hulp aan anderen. Deze toelichting vul je aan met bewijslast uit jouw persoonlijke wiki. 

> Inhoud individuele wiki:

> Documentatie feedbacksessies
> Voorbereiding feedback- en hulpvragen
> ontvangen feedback op teamrol en antwoorden op hulpvragen
> Persoonlijke reflectie op samenwerking a.d.h.v. feedbacksessies

# Introductie & Teamrol
Binnen het team heb ik me voornamelijk bezig gehouden met de functie om in te loggen en te registreren. En met de functie om een match verzoek te kunnen accepteren of weigeren. hieromheen heb ik me in het begin van het project veel bezig gehouden met de vormgeving, zoals het uitkiezen van kleuren, indelen kwa pagina's en het ontwerpen van de header.

Ik merk dat ik soms zo op kan gaan in mijn eigen planning en taken, dat ik me afvraag of mijn betrokkenheid wel altijd goed overkomt op de groep. Hierop hoorde ik dat inderdaad op momenten niet even betrokken leek, bijvoorbeeld ook wanneer ik niet altijd bij de les was, maar ik heb dit naar gevoel naarmate het project gecorrigeerd door meer betrokken te zijn en actiever aan te geven waar ik mee bezig was.

# Ontvangen Feedback
Ik heb gehoord van zowel docenten als teamgenoten dat ik kan proberen om feedback anders op te vangen, namelijk door minder erop in te gaan, en er minder reactief op in te gaan door terug te vragen.

# Conclusie
Mijn bijdrage aan FilmCrew een balans was tussen design, frontend en backend. Door actief feedback te verwerken en mijn werk zorgvuldig te documenteren, ben ik gegroeid in de competenties 'samen ontwerpen' en 'professioneel georganiseerd ontwerpen'. 
Ik vond de samenwerking ook erg fijn in dit project, we hebben zo veel mogelijk samen overlegd, zodat we zoveel mogelijk op een lijn zaten.

Deze ervaring heeft mijn programmeer, samenwerkings en design skills best wel versterkt. ik heb erg veel voortgang gemaakt in mijn begrip van javascript. en mijn manier van feedback verwerken, dat zijn dingen die ik absoluut mee ga nemen in toekomstige werken.