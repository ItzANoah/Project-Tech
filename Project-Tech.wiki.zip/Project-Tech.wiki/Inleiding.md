# Welkom bij ons Project-Tech wiki!
> Noah, Wietse, Anna en Sarah


In deze wiki houden we bij waar we in het project aan werken, welke keuzes we maken en hoe de ontwikkeling verloopt. De wiki is handig om alle belangrijke informatie overzichtelijk te houden en op één plek te verzamelen. Tijdens dit project maken wij een matching website. De website heeft als doel om gebruikers met elkaar te 'matchen' op basis van bepaalde voorkeuren of behoeftes. We documenteren onder andere de functionaliteiten, technische keuzes, voortgangen en eventuele punten waar we op vast lopen. 


