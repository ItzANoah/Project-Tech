# Feedback

## Noah

## Sarah
Tijdens de feedback les heb ik duidelijke feedback gekregen van een ander groepje. Ze hadden weinig aan te merken en vonden dat de matching pagina er al heel goed uitziet. Ook hadden ze geen verdere opmerkingen over hoe de filters nog beter zouden kunnen.

Wel viel een punt op, namelijk wanneer er geen images worden meegestuurd, worden deze ook niet weergegeven op de pagina. Hierdoor krimpt het kaartje helemaal in, het is dus een goed idee om hiervoor een vaste hoogte te gebruiken of iets als een placeholder te tonen met bijvoorbeeld “image not found” of een icoontje.


## Wietse

## Anna Pari