**BEM**

Voor het schrijven class namen hebben wij gekozen om het principe van BEM (Block, element, modifier) te gebruiken. Doordat wij dit gebruiken snappen wij elkaars classnamen, kun je het goed hergebruiken en is het voor iedereen sneller duidelijk.

https://getbem.com/introduction/

https://bem-cheat-sheet.9elements.com/

**Clean Code**

Wij hebben gekeken naar verschillende coding standards en hebben gekozen om met _Clean Code (Ryan McDermott)_ te werken. Hoe de code wordt geschreven voelt voor ons logisch en goed aan en daarom willen we graag deze methode hanteren in ons project.

**Samenvatting van de regels**

1. Variabelen (Namen geven)
Gebruik betekenisvolle namen, vermijd vage namen zoals data of yymmddstr. Gebruik liever currentDate.

Maak ze uitspreekbaar gebruik namen die je hardop kunt voorlezen (bijv. customerRecord in plaats van custRec).

Gebruik doorzoekbare namen vermijd "magic numbers". Gebruik const SECONDS_IN_A_DAY = 86400 in plaats van het getal los in je code te zetten.

Vermijd onnodige context. Als je een object Car hebt, noem de eigenschap dan make, niet carMake.

2. Functies (De kern van je code)
Houd ze klein: Een functie moet maar één ding doen. Als een functie meerdere taken uitvoert, splits hem dan op.

Beperk argumenten: Idealiter heeft een functie 2 of minder argumenten. Heb je er meer nodig? Gebruik dan een object als argument.

Namen moeten acties zijn: Functienamen moeten duidelijk zeggen wat ze doen (bijv. createUser in plaats van user).

Vermijd "flags": Geef geen booleans (true/false) mee aan een functie om te bepalen wat de functie doet. Dit betekent meestal dat de functie twee dingen doet.

Geen bijwerkingen (Side Effects): Een functie moet bij voorkeur alleen een waarde teruggeven en niet ongemerkt variabelen buiten de functie aanpassen.

3. Objecten en Classes
Gebruik getters en setters: Dit maakt het makkelijker om later logica toe te voegen bij het ophalen of instellen van data.

Gebruik ES6 classes: Dit is de standaard in modern JavaScript en zorgt voor een cleanere structuur dan oude prototype-methodes.

4. Condities (If-statements)
Vermijd negatieve condities: Schrijf if (isNodePresent) in plaats van if (!isNodeNotPresent). Dat leest veel natuurlijker.

Kapsel condities in: In plaats van een lange if-regel met veel && en ||, kun je de check in een kleine functie met een duidelijke naam zetten.

5. SOLID Principes
De gids benadrukt ook de vijf SOLID-principes voor objectgeoriënteerd programmeren:

Single Responsibility: Een class mag maar één reden hebben om te veranderen.

Open/Closed: Code moet open staan voor uitbreiding, maar gesloten voor aanpassing.

Liskov Substitution: Subclasses moeten vervangbaar zijn voor hun parent-class zonder dat de code breekt.

Interface Segregation: Forceer gebruikers niet om afhankelijk te zijn van methodes die ze niet gebruiken.

Dependency Inversion: Vertrouw op abstracties, niet op concrete implementaties.

6. Testen
Eén concept per test: Test niet vijf verschillende dingen in één testcase.

Readable tests: Je tests moeten net zo clean en leesbaar zijn als je productiecode.

Kortom: Clean code draait om leesbaarheid. Schrijf code voor de mens die het over een half jaar moet onderhouden, niet voor de computer.