# Individuele wiki
Tijdens dit project heb ik zowel aan het design gewerkt als de frontend en backend gecodeerd van mijn functionaliteit, matching(overzicht) en filteren en sorteren. Mijn taken waren dus, het maken van de wireframes en het bouwen van de matching pagina en filters. Ik heb noUiSlider library geïmplementeerd voor een range en data gekoppeld vanuit MongoDB. De taken hebben we allemaal eerlijk verdeeld en heeft iedereen zijn eigen functionaliteit van voor tot achteren compleet gemaakt. Hierdoor heb ik dus gewerkt aan zowel de visuele als de technische kant van de site.

Tijdens de feedbacksessies heb ik mijn werk laten zien aan verschillende groepjes. Hierbij lag de focus voor mij op de matching pagina, slider, filters en gebruiksvriendelijkheid. 
**Feedback die ik ontvangen heb:**

* Wireframes en stijlblad geven een duidelijk beeld van de werking, sommige pagina’s missen nog wat of kunnen hifi worden uitgewerkt
* De carrousel voor matches kan onhandig zijn wanneer er te veel opties zijn, een grid-layout of kolommen structuur zou beter en overzichtelijker zijn.
* Filters kunnen duidelijker onderscheid maken, bijvoorbeeld profieltype specifieke filters.
* Bij ontbrekende afbeeldingen krimpt het ‘kaartje’ in, vaste hoogte of andere oplossing zou beter zijn.
* Mijn communicatie binnen het team is goed, soms kan ik wat vaker aangeven wanneer ik te veel werk zelf doe en ik kan af en toe meer input geven op punten die mijn teamgenoten opbrengen.


**Voor de sessies stelde ik vragen om gerichte feedback te krijgen:**

* Vinden jullie dat onze wireframes en ontwerpen duidelijk laten zien hoe de website gaat werken?
* Is de grid-layout een beter overzicht nu vergeleken met de carrousel van eerst?
* Hoe kan ik de filters nog beter maken?
* Is de indeling voor desktop en mobiel logisch?

**Ik heb gekregen feedback verwerkt door:**

* De carrousel te vervangen door een grid-layout en het een aparte pagina te maken van de homepage
* Filters te verdelen per type profiel en meer soorten filters toe te voegen
* Placeholder afbeeldingen toegevoegd (image not found) voor images die bijvoorbeeld niet doorgekomen zijn.
* Actiever proberen te communiceren binnen het team

## Reflectie op samenwerking (competentie samen ontwerpen)
Ik heb geleerd dat het belangrijk is om actief feedback te vragen en dit nuttig te verwerken in mijn gemaakte werk. Ik heb kritisch naar ons werk gekeken, elkaar feedback gegeven en zo elke keer het prototype verbeterd. Door vragen te stellen voordat ik het gelijk doorzet, kan ik zorgen dat het eindresultaat goed aansluit bij de gebruikers en binnen het team.

## Projectplanning en verslag (competentie Professioneel en georganiseerd ontwerpen)
Het GitHub projectbord hielp goed om taken te structureren, voor volgende projecten zou ik dit nog wel meer willen gebruiken en toepassen om een goede planning te hebben binnen een team. We spraken met z’n allen deadlines af en hielden ons hier ook aan. We documenteerden beslissingen en feedback in onze wiki. 
**Voor een volgende iteratie wil ik:**

* Meer kijken naar gebruiksvriendelijkheid en er misschien op testen
* Meer feedback verzamelen voor performance gerelateerde code
* GitHub planning beter bijhouden

## Conclusie
Mijn bijdrage aan het project bevat design, frontend en backend. Door actief de feedback te verwerken en mijn werk te documenteren, ben ik gegroeid in de competenties samen ontwerpen en professioneel georganiseerd ontwerpen en heb ik ook geleerd van dingen die beter kunnen. Ook heb ik mij ontwikkeld in mijn programmeer, samenwerking en design vaardigheden.
