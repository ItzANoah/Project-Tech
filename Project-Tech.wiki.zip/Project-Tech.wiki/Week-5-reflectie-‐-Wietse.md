## Feedback vragen:
- Verwachtte of hebben jullie meer communicatie van mij nodig? zijn er over het algemeen dingen qua feedback over mijn communicatie?
communicatie wordt positief ontvangen, helpt doordat we vaak samen zitten, wordt goed opgepakt.
- Zijn mijn taken eerlijk verdeeld? doe ik minder in jullie gevoel, of juist veel?
niet perse, maar ik doe andere dingen, ik doe vooral minder grote dingen.
ik kan iets meer kleine onderdelen als een carrousel maken.

## Oriënteren en begrijpen:
vorige week was vooral het verduidelijken van het concept op basis van de feedback die we kregen. Daarnaast zijn we veel bezig geweest met de wireframes, zodat we een duidelijk startpunt hadden voor onze frontend.
Ook zijn we bezig geweest met wat voor features onze website nou echt nodig had. zoals dat we eigenlijk ook het liefst een kleine chatfunctie zouden toevoegen om het matchen sneller en overzichtelijker te maken.

## Prototypen en uitwerken:
Het prototype tot dusver en het uitwerken daarvan is tot nu toe eigenlijk allemaal gezamenlijk gedaan, het is pas in week 5 dat we echt meer met onze eigen functies en pagina's bezig zijn.
We hebben hierin voor nu vooral gekeken naar de kleuren, we begonnen met een soort blauw en rood achtige mix, ook keken we naar een donkere achtergrond met hoog contrast. maar we kiezen nu voor een kleurenschema met wit, rood, donkergrijs en goud, om een soort oscar en bioscoop sfeer te geven wat goed past bij ons onderwerp en onze doelgroep.