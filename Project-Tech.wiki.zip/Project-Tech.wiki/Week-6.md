week 6

# Dataflow
<img width="1628" alt="Dataflow" src="https://github.com/user-attachments/assets/3478c656-2565-43cb-83d0-c8d2c3aac42e" />
