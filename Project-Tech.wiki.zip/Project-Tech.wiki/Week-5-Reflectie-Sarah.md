Binnen ons groepje neem ik een actieve houding aan. Ik probeer altijd duidelijk te communiceren met de rest. Goede communicatie vind ik belangrijk tijdens projecten waarbij je moet samenwerken, zo voorkom je misverstanden en blijft iedereen goed op de hoogte. Daarnaast stel ik vaak vragen wanneer iets nog niet helemaal duidelijk is. Door te vragen stellen begrijp ik het helemaal voordat ik ergens aan ga werken. Dit helpt dan ook om goede resultaten te leveren en zorgt het er ook voor dat we als team beter nadenken over bepaalde keuzes. Ik sta ook altijd open voor feedback en probeer deze feedback dan ook toe te passen. Door kritisch naar ons werk te kijken en elkaar feedback te geven zorgen we ervoor dat we ons concept blijven verbeteren.


## Feedbackvragen ##
* Vinden jullie dat onze wireframes en ontwerpen duidelijk laten zien hoe de website gaat werken?

> ja, missen nog wel een paar pagina’s, geeft goed beeld van de werking. Iets meer hifi maken van de schermen, de rest goed. Soms verwarrend met bepaalde keuzes.

* Hebben jullie het gevoel dat ik actief bijdraag aan het teamproces?

> Ja best wel, veel input en meningen vooral tijdens het design maken. Ja altijd als je er bent, altijd goed aan het werk. Ik kan nog wat meer aangeven wanneer ik te veel zou doen, communiceer meer dat ik niet alles zelf doe.

* Hoe ervaren jullie mijn communicatie binnen het team?

> Goed, laat weten als ik teveel doe

* Wat is volgens jullie een punt waarop ik mijn samenwerking nog kan verbeteren?

> Kan iets meer input geven op bepaalde punten

* Denken jullie dat er nog verbeterpunten zijn bij het uitwerken van het prototype/code

> Duidelijker regels met z'n allen opzetten


### Verbeelden en conceptualiseren ###
We hebben veel gekeken naar wat de gebruiker zou willen en welke belangen diegene heeft. We hebben dit gedaan op basis van job stories die we samengesteld hebben. Zo hebben we ook tijdens het maken van de wireframes bedacht wat goed is voor de gebruikers. We willen het makkelijk maken voor gebruikers, zo kan je bijvoorbeeld alles aanpassen in je profiel, worden er suggesties voor matches aangegeven en kun je je voorkeuren doorgeven.

### Prototype en uitwerken ###
We hebben sinds vorige week alles af qua design en stijlblad. We zijn vervolgens gaan bespreken en gaan kijken wat we nog samen konden opzetten aan code. Dit was goed gelukt, vanaf deze week zijn we dus hard aan de slag met onze eigen functionaliteiten en branches.
