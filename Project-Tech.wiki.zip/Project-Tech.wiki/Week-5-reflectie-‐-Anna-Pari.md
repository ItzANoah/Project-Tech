## **Feedbackvragen**

Vinden jullie dat ik genoeg input geeft?

Wauw, het verschilt per onderwerp. Meer dat het natuurlijker komt. Het mag meer maar het is niet te weinig. Als je input geeft is het goede impit. Soms lijkt het alsof je heel moe bent.

Zijn er dingen die ik kan verbeteren in de communicatie?

Gaat goed.

## **Orienteren en begrijpen**

We hebben doormiddel van een requirements list ons ingeleefd in de gebruiker en bedacht wat de gebruikers in onze website willen zien. Op basis van deze requirements maken we ontwerpkeuzes om het product zo goed mogelijk te maken voor onze doelgroep.

Zo hebben we als requirement dat gebruikers hun eigen profiel moeten kunnen aanpassen, dit hebben we ook meegenomen bij het ontwerpen van de wireframes.

## **Verbeelden en conceptualiseren**

We hebben onze concept gevisualiseerd doormiddel van het maken van de wireframes en stylesheet. Nu weten we hoe we ons uiteindelijke project willen hebben.

## **Prototypen en uitwerken**

We hebben ons stylesheet vertaald naar de css, nu kunnen we ons gemakkelijk aan de stylesheet houden. Ook hebben we meerdere pakketjes geinstalleerd die ons gaan ondersteunen tijdens het verder uitwerken, zoals bijvoorbeeld stylelint.