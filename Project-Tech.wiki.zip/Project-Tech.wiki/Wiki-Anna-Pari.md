# Individuele Wiki Anna 

Mijn individuele reflectie op mijn rol binnen het team en hoe ik feedback verwerkt heb.

## Feedbacksessies

Ter voorbereiding van de feebdacksessies heb ik vragen opgesteld voor mijn teamgenoten.
**Feedbackvragen**

* Vinden jullie dat ik genoeg input geeft?
* Zijn er dingen die ik kan verbeteren in de communicatie?
* Zijn jullie tevreden met hoe de rollen verdeeld zijn
* Past de styling van mijn pagina goed bij de rest van de website


**Feedback van mijn eigen team**
* Beter gebruik maken van partials
* Overwegen of je wel of niet de gebruiker hun eigen ervaring bij een project erbij laat zetten
* Consistent qua taal blijven (Engels & Nederlands)
* Javascript van partials niet in .ejs bestand onder <script>, maar in een apart .js bestand

**Feedback van andere teams**
* Als je nu project wil toevoeg niet perse alleen als je je profiel aan het editten bent. Beetje overbodige stappen nu namelijk.
* Misschien de tekst van de gebruiker zelf is aan de lange kant, misschien korter houden voor leesbaarheid.
* Volgorde klopt niet nadat je een nieuwe aanmaakt. Kijken of het chronologisch kan staan.
* Bij het project toevoegen ook de gele lijntjes, geeft de verkeerde indruk.
* geel niet heel goed leesbaar

**Hoe ik mijn feedback verwerkt heb**

Ik heb deze feedback meteen opgepakt en ben meer gaan werken met partials op de juiste manier. Ook heb ik de feedback van het andere team toegepast en mijn pagina gebruiksvriendelijker te maken. Door bijvoorbeeld de project toevoegen knop altijd zichtbaar te houden voor de gebruiker zelf zodat dat een extra onnodige stap voor hen scheelt.

## Individuele reflectie samenwerking (competentie samen ontwerpen)

Ik vond de samenwerking dit project erg goed gaan. Aan het begin van het blok waren we veel samen aan het werken bij het bedenken van ons concept, het plannen voor hoe we het aan wilden gaan pakken en de basis qua stijl en hoe de website opgebouwd zou worden. Ook de opzet van de code en server hebben we samen gedaan. Vervolgens hebben we verdeeld wie welke pagina's en features uit ging werken. Vanaf dat moment zijn we echt meer individueel aan de slag gegaan met onze eigen features. 

Binnen het team merkte ik dat ik aan het begin van het project erg actief was, tijdens het bedenken van ons concept en het maken van de stylesheet, wireframes enzovoort. Toen we vervolgens echt met de code begonnen vond ik dat toch erg ingewikkeld en had ik wat langer de tijd nodig om alles echt te begrijpen. In die fase van het project verloor ik echt eventjes motivatie. Gelukkig kon ik bij mijn team en docenten terecht met vragen en doormiddel van gewoon doen en proberen heb ik uiteindelijk toch door hoe het allemaal werkt.

Zo liep ik uiteindelijk niet meer vast en heb ik mijn eigen feature goed uit kunnen werken. Met de eind merge naar de dev was ik ook erg blij dat alles erg soepeltjes verliep. Ik denk dat dit ook bewijst dat we een echte goede basis voor dit project hadden gezet als team, en individueel serieus aan de slag zijn gegaan.
